/* @(#)CommonModel.java Sep 3, 2015
 *
 * Copyright (c) 2015. All rights reserved.
 */

package io.github.rampantlions.codetools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.internal.bind.DateTypeAdapter;
import com.google.gson.stream.JsonReader;

import io.github.rampantlions.codetools.gson.utils.GsonExclusionStrategy;
import io.github.rampantlions.codetools.gson.utils.UTCTimestampType;

/**
 * The Class CommonModel.
 *
 * @author Wiechman, Joshua <jwiechman@paypal.com>
 * @param <T> the generic type
 */
@java.lang.SuppressWarnings( { "serial" } )
@MappedSuperclass
// @Inheritance( strategy = InheritanceType.JOINED )
public abstract class CommonModel< T extends CommonModel< T > > implements java.io.Serializable, java.lang.Cloneable
{
	/** The gson__. */
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	@javax.persistence.Transient
	protected static final transient Gson gson__ = new GsonBuilder().setPrettyPrinting().setExclusionStrategies( new GsonExclusionStrategy( null ) ).registerTypeAdapter( Date.class, new DateTypeAdapter() ).create();

	/**
	 * Contains.
	 *
	 * @param queryName the query name
	 * @param parms the parms
	 * @param session the session
	 * @return true, if successful
	 */
	public static boolean contains( final String queryName, final Map< String, Object > parms, final Session session )
	{
		return ( CommonModel.get( queryName, parms, session ).size() > 0 );
	}

	/**
	 * From json.
	 *
	 * @param <CType> the generic type
	 * @param json the json
	 * @param clazz the clazz
	 * @return the c type
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 * @throws FileNotFoundException the file not found exception
	 */
	public static < CType > CType fromJson( final File json, final Class< CType > clazz ) throws UnsupportedEncodingException, FileNotFoundException
	{
		FileInputStream in = new FileInputStream( json );
		JsonReader reader = new JsonReader( new InputStreamReader( in, "UTF-8" ) );
		return gson__.fromJson( reader, clazz );
	}

	/**
	 * From json.
	 *
	 * @param <CType> the generic type
	 * @param json the json
	 * @param clazz the clazz
	 * @return the c type
	 */
	public static < CType > CType fromJson( final JsonObject json, final Class< CType > clazz )
	{
		return fromJson( json.toString(), clazz );
	}

	/**
	 * From json.
	 *
	 * @param <CType> the generic type
	 * @param json the json
	 * @param clazz the clazz
	 * @return the c type
	 */
	public static < CType > CType fromJson( final JSONObject json, final Class< CType > clazz )
	{
		return gson__.fromJson( json.toString(), clazz );
	}

	/**
	 * From json.
	 *
	 * @param <CType> the generic type
	 * @param json the json
	 * @param clazz the clazz
	 * @return the c type
	 */
	@javax.ws.rs.Consumes( "application/json" )
	public static < CType > CType fromJson( final Gson gson, final String json, final Class< CType > clazz )
	{
		return gson.fromJson( json, clazz );
	}

	@javax.ws.rs.Consumes( "application/json" )
	public static < CType > CType fromJson( final String json, final Class< CType > clazz )
	{
		return fromJson( gson__, json, clazz );
	}

	/**
	 * From json.
	 *
	 * @param <CType> the generic type
	 * @param jsonUrl the json url
	 * @param clazz the clazz
	 * @return the c type
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static < CType > CType fromJson( final URL jsonUrl, final Class< CType > clazz ) throws IOException
	{
		JsonReader reader = new JsonReader( new InputStreamReader( jsonUrl.openStream(), "UTF-8" ) );
		return gson__.fromJson( reader, clazz );
	}

	/**
	 * From xml.
	 *
	 * @param <CType> the generic type
	 * @param xml the xml
	 * @param clazz the clazz
	 * @return the c type
	 * @throws JAXBException the JAXB exception
	 * @throws FileNotFoundException the file not found exception
	 */
	@SuppressWarnings( "unchecked" )
	public static < CType > CType fromXml( final File xml, final Class< CType > clazz ) throws JAXBException, FileNotFoundException
	{
		JAXBContext jaxbContext = JAXBContext.newInstance( clazz );
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

		FileInputStream in = new FileInputStream( xml );

		CType returntype = (CType) jaxbUnmarshaller.unmarshal( in );

		return returntype;
	}

	/**
	 * From xml.
	 *
	 * @param <CType> the generic type
	 * @param xml the xml
	 * @param clazz the clazz
	 * @return the c type
	 * @throws JAXBException the JAXB exception
	 */
	@SuppressWarnings( "unchecked" )
	@javax.ws.rs.Consumes( "application/xml" )
	public static < CType > CType fromXml( final String xml, final Class< CType > clazz ) throws JAXBException
	{
		JAXBContext jaxbContext = JAXBContext.newInstance( clazz );
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

		InputStreamReader is = new InputStreamReader( IOUtils.toInputStream( xml ) );

		// FileInputStream in = new FileInputStream( new File( folder + field.getType().getTypeArguments().get( LISTTYPEPOSITION ) + DOTJAVA ) );

		CType returntype = (CType) jaxbUnmarshaller.unmarshal( is );

		return returntype;
	}

	/**
	 * From xml.
	 *
	 * @param <CType> the generic type
	 * @param xmlUrl the xml url
	 * @param clazz the clazz
	 * @return the c type
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws JAXBException the JAXB exception
	 */
	@SuppressWarnings( "unchecked" )
	public static < CType > CType fromXml( final URL xmlUrl, final Class< CType > clazz ) throws IOException, JAXBException
	{
		JAXBContext jaxbContext = JAXBContext.newInstance( clazz );
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		CType returntype = (CType) jaxbUnmarshaller.unmarshal( new InputStreamReader( xmlUrl.openStream(), "UTF-8" ) );
		return returntype;
	}

	/**
	 * Gets the.
	 *
	 * @param queryName the query name
	 * @param parms the parms
	 * @param session the session
	 * @return the list
	 */
	@SuppressWarnings( { "rawtypes" } )
	public static List get( final String queryName, final Map< String, Object > parms, final Session session )
	{
		Query query = session.getNamedQuery( queryName );

		if ( parms != null )
		{
			for ( Entry< String, Object > parm : parms.entrySet() )
			{
				if ( parm.getValue() instanceof String )
				{
					query.setString( parm.getKey(), (String) parm.getValue() );
				}
				else
				{
					query.setParameter( parm.getKey(), parm.getValue() );
				}
			}
		}
		return query.list();
	}

	/**
	 * Gets the field.
	 *
	 * @param clazz the clazz
	 * @return the field
	 * @throws NoSuchFieldException the no such field exception
	 */
	@SuppressWarnings( { "unchecked", "rawtypes" } )
	private static List< Field > getField( final Class clazz ) throws NoSuchFieldException
	{
		List< Field > fields = new ArrayList< Field >();
		fields.addAll( Arrays.asList( clazz.getDeclaredFields() ) );
		if ( !clazz.getSuperclass().isAssignableFrom( Object.class ) )
		{
			// Extra Check for Circular Logic?

			fields.addAll( CommonModel.getField( clazz.getSuperclass() ) );
		}

		return fields;
	}

	/** The additional properties. */
	@javax.persistence.Transient
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	private transient Map< String, Object > additionalProperties__ = new HashMap< String, Object >();

	/** The enabled. */
	@com.wordnik.swagger.annotations.ApiModelProperty( value = "Is this entry enabled.", notes = " ", required = true )
	@javax.persistence.Column( name = "Hibernate__Enabled" )
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	@org.hibernate.annotations.Type( type = "yes_no" )
	protected boolean enabled__ = true;

	/** The id__. */
	@com.wordnik.swagger.annotations.ApiModelProperty( value = "The Hibernate ID of this entry.", notes = " ", required = true )
	@javax.xml.bind.annotation.XmlAttribute
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	@javax.persistence.GeneratedValue( strategy = javax.persistence.GenerationType.AUTO )
	@javax.persistence.Column( name = "Hibernate__ID", unique = true, nullable = false )
	@javax.persistence.Id
	protected long id__;
	// @javax.persistence.Id
	// @org.hibernate.annotations.GenericGenerator( name = "system-uuid", strategy = "uuid" )
	// @javax.persistence.GeneratedValue( generator = "system-uuid" )
	// @javax.persistence.Column( length = 32 )
	// private String id__;

	/** The record creation date__. */
	@com.wordnik.swagger.annotations.ApiModelProperty( value = "The creation date of this entry.", notes = " ", required = false )
	@org.hibernate.annotations.Type( type = "java.sql.Timestamp" )
	@javax.persistence.Column( name = "Hibernate__Creation" )
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	// @Temporal(TemporalType.DATE)
	protected Date recordCreationDate__ = ( UTCTimestampType.getUtc() );

	/** The record modification date__. */
	@com.wordnik.swagger.annotations.ApiModelProperty( value = "The revision date of this entry.", notes = " ", required = false )
	@org.hibernate.annotations.Type( type = "java.sql.Timestamp" )
	@javax.persistence.Column( name = "Hibernate__Modification" )
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	protected Date recordModificationDate__ = ( UTCTimestampType.getUtc() );

	/** The version__. */
	@com.wordnik.swagger.annotations.ApiModelProperty( value = "The version or revision of this entry.", notes = " ", required = true )
	@javax.persistence.Column( name = "Hibernate__Version" )
	@javax.persistence.Version
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	protected int version__ = 0;

	/**
	 * equals
	 * (non-Javadoc).
	 *
	 * @param other the other
	 * @return true, if successful
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals( final Object other )
	{
		return EqualsBuilder.reflectionEquals( this, other );
	}

	/**
	 * Gets the additional properties.
	 *
	 * @return the additional properties
	 */
	@com.fasterxml.jackson.annotation.JsonAnyGetter
	@org.codehaus.jackson.annotate.JsonAnyGetter
	public Map< String, Object > getAdditionalProperties()
	{
		return this.additionalProperties__;
	}

	/**
	 * Gets the list type.
	 *
	 * @param field the field
	 * @return the list type
	 */
	private Class< ? > getListType( final Field field )
	{
		ParameterizedType stringListType = (ParameterizedType) field.getGenericType();
		Class< ? > listType = (Class< ? >) stringListType.getActualTypeArguments()[0];
		return listType;
	}

	/**
	 * Gets the map type.
	 *
	 * @param field the field
	 * @param key the key
	 * @return the map type
	 */
	private Class< ? > getMapType( Field field, boolean key )
	{
		ParameterizedType stringMapType = (ParameterizedType) field.getGenericType();
		Class< ? > mapType = (Class< ? >) stringMapType.getActualTypeArguments()[( ( key ) ? 0 : 1 )];
		return mapType;
	}

	/**
	 * Gets the sets the type.
	 *
	 * @param field the field
	 * @return the sets the type
	 */
	private Class< ? > getSetType( Field field )
	{
		ParameterizedType stringSetType = (ParameterizedType) field.getGenericType();
		Class< ? > setType = (Class< ? >) stringSetType.getActualTypeArguments()[0];
		return setType;
	}

	/**
	 * Gets the gson__.
	 *
	 * @return the gson__
	 */
	public Gson gson()
	{
		return gson__;
	}

	/**
	 * hashCode
	 * (non-Javadoc).
	 *
	 * @return the int
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode()
	{
		return HashCodeBuilder.reflectionHashCode( this );
	}

	/**
	 * Checks for many to one.
	 *
	 * @param field the field
	 * @return true, if successful
	 */
	private boolean hasManyToOne( final Field field )
	{
		return ( field.getAnnotation( javax.persistence.ManyToOne.class ) != null );
	}

	/**
	 * Checks for one to many.
	 *
	 * @param field the field
	 * @return true, if successful
	 */
	@SuppressWarnings( "unused" )
	private boolean hasOneToMany( final Field field )
	{
		return ( field.getAnnotation( javax.persistence.OneToMany.class ) != null );
	}

	/**
	 * Checks for one to one.
	 *
	 * @param field the field
	 * @return true, if successful
	 */
	@SuppressWarnings( "unused" )
	private boolean hasOneToOne( final Field field )
	{
		return ( field.getAnnotation( javax.persistence.OneToOne.class ) != null );
	}

	/**
	 * Hibernate get creation date.
	 *
	 * @return the date
	 */
	@javax.xml.bind.annotation.XmlTransient
	public Date hibernateGetCreationDate()
	{
		return recordCreationDate__;
	}

	/**
	 * Hibernate get id.
	 *
	 * @return the int
	 */
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	public long hibernateGetId()
	{
		return id__;
	}

	/**
	 * Hibernate get modified date.
	 *
	 * @return the date
	 */
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	public Date hibernateGetModifiedDate()
	{
		return recordModificationDate__;
	}

	/**
	 * Hibernate get version.
	 *
	 * @return the int
	 */
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	public int hibernateGetVersion()
	{
		return version__;
	}

	/**
	 * Checks if is enabled.
	 *
	 * @return true, if is enabled
	 */
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	public boolean hibernateIsEnabled()
	{
		return enabled__;
	}

	/**
	 * Hibernate on create.
	 *
	 * @return the t
	 */
	@SuppressWarnings( "unchecked" )
	@PrePersist
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	private T hibernateOnCreate()
	{
		recordCreationDate__ = UTCTimestampType.getUtc();
		org.hibernate.Hibernate.initialize( recordCreationDate__ );
		recordModificationDate__ = UTCTimestampType.getUtc();
		org.hibernate.Hibernate.initialize( recordModificationDate__ );
		return (T) this;
	}

	/**
	 * Hibernate on update.
	 *
	 * @return the t
	 */
	@SuppressWarnings( "unchecked" )
	@PreUpdate
	@com.fasterxml.jackson.annotation.JsonIgnore
	@org.codehaus.jackson.annotate.JsonIgnore
	@io.github.rampantlions.codetools.annotations.GsonExclude
	@javax.xml.bind.annotation.XmlTransient
	private T hibernateOnUpdate()
	{
		recordModificationDate__ = UTCTimestampType.getUtc();
		org.hibernate.Hibernate.initialize( recordModificationDate__ );
		return (T) this;
	}

	/**
	 * Hibernate save.
	 *
	 * @return the t
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws IllegalAccessException the illegal access exception
	 * @throws NoSuchFieldException the no such field exception
	 */
	@SuppressWarnings( { "unchecked" } )
	public T hibernateSave() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException
	{
		Session session = HibernateClient.getSessionFactory().openSession();
		if ( !session.getTransaction().isActive() )
		{
			session.getTransaction().begin();
		}
		hibernateSave( session );
		session.getTransaction().commit();
		session.close();
		return (T) this;
	}

	/**
	 * Hibernate save.
	 *
	 * @param session the session
	 * @return the t
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws IllegalAccessException the illegal access exception
	 * @throws NoSuchFieldException the no such field exception
	 */
	@SuppressWarnings( { "unchecked" } )
	public T hibernateSave( final Session session ) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException
	{
		Transaction transaction = session.getTransaction();
		if ( transaction == null )
		{
			transaction = session.beginTransaction();
		}

		if ( !transaction.isActive() )
		{
			transaction.begin();
		}

		hibernateSave( transaction, session );

		transaction.commit();
		return (T) this;
	}

	/**
	 * Hibernate save.
	 *
	 * @param sessionFactory the session factory
	 * @return the t
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws IllegalAccessException the illegal access exception
	 * @throws NoSuchFieldException the no such field exception
	 */
	@SuppressWarnings( "unchecked" )
	public T hibernateSave( final SessionFactory sessionFactory ) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException
	{
		Session session = sessionFactory.openSession();
		if ( !session.getTransaction().isActive() )
		{
			session.getTransaction().begin();
		}
		hibernateSave( session );
		session.getTransaction().commit();
		session.close();
		return (T) this;
	}

	/**
	 * Hibernate save.
	 *
	 * @param sessionFactory the session factory
	 * @param session the session
	 * @return the t
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws IllegalAccessException the illegal access exception
	 * @throws NoSuchFieldException the no such field exception
	 */
	@SuppressWarnings( "unchecked" )
	public T hibernateSave( final SessionFactory sessionFactory, final Session session ) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException
	{
		if ( !session.getTransaction().isActive() )
		{
			session.getTransaction().begin();
		}
		hibernateSave( session );
		session.getTransaction().commit();
		return (T) this;
	}

	/**
	 * Hibernate save.
	 *
	 * @param transaction the transaction
	 * @param session the session
	 * @return the t
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws IllegalAccessException the illegal access exception
	 * @throws NoSuchFieldException the no such field exception
	 */
	@SuppressWarnings( { "unchecked", "rawtypes" } )
	public T hibernateSave( Transaction transaction, Session session ) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException
	{
		org.hibernate.Hibernate.initialize( recordCreationDate__ );
		org.hibernate.Hibernate.initialize( recordModificationDate__ );

		List< Field > fields = CommonModel.getField( ( (T) this ).getClass() );
		for ( Field field : fields )
		{
			if ( field != null )
			{
				field.setAccessible( true );
			}

			if ( isList( field ) )
			{
				Class< ? > listType = getListType( field );
				if ( isCommonModel( listType ) )
				{
					// if ( hasOneToMany( field ) )
					// {
					List tmpList = (List) field.get( this );
					if ( tmpList != null )
					{
						for ( Object tmp : tmpList )
						{
							CommonModel< ? extends CommonModel > cm = (CommonModel) ( listType.cast( tmp ) );
							cm.hibernateSave( transaction, session );
						}
					}
					// }
				}
			}
			else if ( isSet( field ) )
			{
				Class< ? > setType = getSetType( field );
				if ( isCommonModel( setType ) )
				{
					// if ( hasOneToMany( field ) )
					// {
					Set tmpSet = (Set) field.get( this );
					if ( tmpSet != null )
					{
						for ( Object tmp : tmpSet )
						{
							CommonModel< ? extends CommonModel > cm = (CommonModel) ( setType.cast( tmp ) );
							cm.hibernateSave( transaction, session );
						}
					}
					// }
				}
			}
			else if ( isMap( field ) )
			{
				Class< ? > mapKeyType = getMapType( field, true );
				Class< ? > mapValueType = getMapType( field, false );
				if ( isCommonModel( mapKeyType ) )
				{
					// if ( hasOneToMany( field ) )
					// {
					Map tmpMap = (Map) field.get( this );
					if ( tmpMap != null )
					{
						for ( Object tmp : tmpMap.entrySet() )
						{
							CommonModel< ? extends CommonModel > cm = (CommonModel) ( mapKeyType.cast( ( Entry.class.cast( tmp ) ).getKey() ) );
							cm.hibernateSave( transaction, session );
						}
					}
					// }
				}

				if ( isCommonModel( mapValueType ) )
				{
					// if ( hasOneToMany( field ) )
					// {
					Map tmpMap = (Map) field.get( this );
					if ( tmpMap != null )
					{
						for ( Object tmp : tmpMap.entrySet() )
						{
							CommonModel< ? extends CommonModel > cm = (CommonModel) ( mapValueType.cast( ( Entry.class.cast( tmp ) ).getValue() ) );
							cm.hibernateSave( transaction, session );
						}
					}
					// }
				}
			}
			else
			{
				if ( CommonModel.class.isAssignableFrom( field.getType() ) )
				{
					if ( !hasManyToOne( field ) )
					{
						Class< ? > commonModelType = null;
						try
						{
							commonModelType = getListType( field );
						}
						catch ( Exception e )
						{
							commonModelType = field.getType();
						}

						if ( commonModelType != null )
						{
							Object tmpObj = field.get( this );
							if ( tmpObj != null )
							{
								CommonModel< ? extends CommonModel > cm = (CommonModel) ( commonModelType.cast( tmpObj ) );
								cm.hibernateSave( transaction, session );
							}
						}
					}
				}
			}
		}

		try
		{
			session.saveOrUpdate( this );
			// session.flush();
			// session.clear();
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}

		for ( Field field : fields )
		{
			if ( List.class.isAssignableFrom( field.getType() ) )
			{
				Class< ? > listType = getListType( field );
				if ( CommonModel.class.isAssignableFrom( listType ) )
				{
					if ( field.getAnnotation( javax.persistence.OneToMany.class ) != null )
					{

						OneToMany annotation = field.getAnnotation( javax.persistence.OneToMany.class );
						String childField = annotation.mappedBy();

						List tmpList = (List) field.get( this );
						if ( tmpList != null )
						{
							for ( Object tmp : tmpList )
							{
								CommonModel< ? extends CommonModel > cm = (CommonModel) ( listType.cast( tmp ) );
								List< Field > childFields = CommonModel.getField( listType );
								for ( Field childF : childFields )
								{
									if ( childF.getName().equals( childField ) && ( childF.getType().isAssignableFrom( this.getClass() ) ) )
									{
										childF.setAccessible( true );
										childF.set( cm, this );
									}
								}
								cm.hibernateSave( transaction, session );
							}
						}
					}
				}
			}
			else if ( Set.class.isAssignableFrom( field.getType() ) )
			{
				Class< ? > setType = getSetType( field );
				if ( CommonModel.class.isAssignableFrom( setType ) )
				{
					if ( field.getAnnotation( javax.persistence.OneToMany.class ) != null )
					{
						OneToMany annotation = field.getAnnotation( javax.persistence.OneToMany.class );
						String childField = annotation.mappedBy();

						List tmpList = (List) field.get( this );
						if ( tmpList != null )
						{
							for ( Object tmp : tmpList )
							{
								CommonModel< ? extends CommonModel > cm = (CommonModel) ( setType.cast( tmp ) );
								List< Field > childFields = CommonModel.getField( setType );
								for ( Field childF : childFields )
								{
									if ( childF.getName().equals( childField ) && ( childF.getType().isAssignableFrom( this.getClass() ) ) )
									{
										childF.setAccessible( true );
										childF.set( cm, this );
									}
								}
								cm.hibernateSave( transaction, session );
							}
						}
					}
				}
			}
		}
		return (T) this;
	}

	/**
	 * Sets the enabled.
	 *
	 * @param enabled the enabled
	 * @return the t
	 */
	@SuppressWarnings( "unchecked" )
	public T hibernateSetEnabled( final boolean enabled )
	{
		this.enabled__ = enabled;
		return (T) this;
	}

	/**
	 * Checks if is collection.
	 *
	 * @param clss the clss
	 * @return true, if is collection
	 */
	@SuppressWarnings( "unused" )
	private boolean isCollection( final Class< ? > clss )
	{
		return Collection.class.isAssignableFrom( clss );
	}

	/**
	 * Checks if is common model.
	 *
	 * @param clss the clss
	 * @return true, if is common model
	 */
	private boolean isCommonModel( final Class< ? > clss )
	{
		return CommonModel.class.isAssignableFrom( clss );
	}

	/**
	 * Checks if is list.
	 *
	 * @param clss the clss
	 * @return true, if is list
	 */
	private boolean isList( final Class< ? > clss )
	{
		return List.class.isAssignableFrom( clss );
	}

	/**
	 * Checks if is list.
	 *
	 * @param field the field
	 * @return true, if is list
	 */
	private boolean isList( final Field field )
	{
		return isList( field.getType() );
	}

	/**
	 * Checks if is map.
	 *
	 * @param clss the clss
	 * @return true, if is map
	 */
	private boolean isMap( final Class< ? > clss )
	{
		return Map.class.isAssignableFrom( clss );
	}

	/**
	 * Checks if is map.
	 *
	 * @param field the field
	 * @return true, if is map
	 */
	private boolean isMap( Field field )
	{
		return isMap( field.getType() );
	}

	/**
	 * Checks if is sets the.
	 *
	 * @param clss the clss
	 * @return true, if is sets the
	 */
	private boolean isSet( final Class< ? > clss )
	{
		return Set.class.isAssignableFrom( clss );
	}

	/**
	 * Checks if is sets the.
	 *
	 * @param field the field
	 * @return true, if is sets the
	 */
	private boolean isSet( Field field )
	{
		return isSet( field.getType() );
	}

	/**
	 * Sets the additional property.
	 *
	 * @param name the name
	 * @param value the value
	 * @return the t
	 */
	@SuppressWarnings( "unchecked" )
	@com.fasterxml.jackson.annotation.JsonAnySetter
	@org.codehaus.jackson.annotate.JsonAnySetter
	@javax.xml.bind.annotation.XmlTransient
	public T setAdditionalProperty( final String name, final Object value )
	{
		this.additionalProperties__.put( name, value );
		return (T) this;
	}

	/**
	 * To json.
	 *
	 * @return the string
	 */
	@javax.ws.rs.Produces( "application/json" )
	public String toJson()
	{
		return gson__.toJson( this );
	}

	/**
	 * To json object.
	 *
	 * @return the json object
	 */
	@javax.xml.bind.annotation.XmlTransient
	public JsonObject toJsonObject()
	{
		// return new JsonParser().parse( toJson() ).getAsJsonObject();
		return gson__.fromJson( toJson(), JsonElement.class ).getAsJsonObject();
	}

	/**
	 * To json object.
	 *
	 * @return the JSON object
	 * @throws JSONException the JSON exception
	 */
	@javax.xml.bind.annotation.XmlTransient
	public JSONObject toJSONObject() throws JSONException
	{
		return new JSONObject( toJson() );
	}

	/**
	 * toString
	 * (non-Javadoc).
	 *
	 * @return the string
	 * @see java.lang.Object#toString()
	 */
	@Override
	@javax.ws.rs.Produces( "text/plain" )
	@javax.xml.bind.annotation.XmlTransient
	public String toString()
	{
		return ToStringBuilder.reflectionToString( ( this ) );
	}

	/**
	 * To xml.
	 *
	 * @return the string
	 * @throws JSONException the JSON exception
	 */
	@javax.ws.rs.Produces( "application/xml" )
	@javax.xml.bind.annotation.XmlTransient
	public String toXml() throws JSONException
	{
		// String result;
		// StringWriter sw = new StringWriter();
		// try
		// {
		// JAXBContext context = JAXBContext.newInstance( this.getClass() );
		// Marshaller marshaller = context.createMarshaller();
		// marshaller.setProperty( Marshaller.JAXB_FORMATTED_OUTPUT, true );
		// marshaller.marshal( this, sw );
		// result = sw.toString();
		// }
		// catch ( JAXBException e )
		// {
		// throw new RuntimeException( e );
		// }

		// try
		// {
		// Document document = null;
		//
		// try
		// {
		// DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		// DocumentBuilder db = dbf.newDocumentBuilder();
		// InputSource is = new InputSource( new StringReader( XML.toString( this ) ) );
		// document = db.parse( is );
		// }
		// catch ( ParserConfigurationException e )
		// {
		// throw new RuntimeException( e );
		// }
		// catch ( SAXException e )
		// {
		// throw new RuntimeException( e );
		// }
		// catch ( IOException e )
		// {
		// throw new RuntimeException( e );
		// }
		//
		// if ( document != null )
		// {
		// OutputFormat format = new OutputFormat( document );
		// format.setLineWidth( 65 );
		// format.setIndenting( true );
		// format.setIndent( 2 );
		// Writer out = new StringWriter();
		// XMLSerializer serializer = new XMLSerializer( out, format );
		// serializer.serialize( document );
		//
		// return out.toString();
		// }
		// }
		// catch ( IOException e )
		// {
		// throw new RuntimeException( e );
		// }

		return XML.toString( this );
	}
}
